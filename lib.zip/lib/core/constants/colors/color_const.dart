import 'package:flutter/material.dart';

class ColorsConst {
  static Color colorE1B412 = const Color(0xffE1B412);
  static Color color01957D = const Color(0xff01957D);
  static Color color0F2542 = const Color(0xff0F2542);
  static Color color212D3D = const Color(0xff212D3D);
  static Color color969696 = const Color(0xff969696);
  static Color color94A1B2 = const Color(0xff94A1B2);
  static Color colorE5E5E5 = const Color(0xffE5E5E5);
  static Color color000000 = const Color(0xff000000);
  static Color colorFEFEFE = const Color(0xffFEFEFE);
  static Color colorFFFFFF = const Color(0xffFFFFFF);
}
