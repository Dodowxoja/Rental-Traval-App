abstract class DetailsState {}

class DetailsInitial extends DetailsState {}
