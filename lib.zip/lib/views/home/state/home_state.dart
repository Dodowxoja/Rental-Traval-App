abstract class HomeState {}

class HomeInitial extends HomeState {}
